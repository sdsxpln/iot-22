#include <config.h>
#include <lwip/sockets.h>
#include <lwip/netif.h>
#include <lwip/ip_addr.h>
#include <netapp/net_app.h>
#include "cli_cmd_sim.h"


void cmd_createsocketclient (s32 argc, s8 *argv[])
{
// 		if (argc != 2)
// 	    {
// 	        LOG_PRINTF("Bad command\n");
// 			LOG_PRINTF("input exapmle -> socket-c 127.0.0.1 \n");
// 	        return;
// 	    }
//    SocketClient_ConnectServer(argv[1]);
} // end of - cmd_createsocketclient -






