#ifndef _CLI_CMD_THROUGHPUT_H_
#define _CLI_CMD_THROUGHPUT_H_
#include <host_apis.h>

void cmd_throughput(s32 argc, s8 *argv[]);

#endif /* _CLI_CMD_SDIO_TEST_H_ */

