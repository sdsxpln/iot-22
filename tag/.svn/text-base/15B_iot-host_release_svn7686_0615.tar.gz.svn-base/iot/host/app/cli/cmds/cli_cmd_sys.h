#ifndef _CLI_CMD_SYS_H_
#define _CLI_CMD_SYS_H_

void cmd_sys(s32 argc, s8 *argv[]);	
#endif
