#ifndef _CLI_CMD_TEST_H_
#define _CLI_CMD_TEST_H_

//void cmd_iw(s32 argc, s8 *argv[]);

void cmd_test(s32 argc, s8 *argv[]);

#endif /* _CLI_CMD_TEST_H_ */

