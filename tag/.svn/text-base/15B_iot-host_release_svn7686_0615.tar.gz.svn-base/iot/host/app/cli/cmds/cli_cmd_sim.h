#ifndef _CLI_CMD_SIM_
#define _CLI_CMD_SIM_

void cmd_createsocketclient(s32 argc, s8 *argv[]);
void cmd_ap(s32 argc, s8 *argv[]);


#endif /* _CLI_CMD_SIM_ */
