#ifndef _WSIMP_SIM_H_
#define _WSIMP_SIM_H_






s32 wsimp_run_sim(s32 argc, s8 *argv[]);


#endif /* _WSIMP_SIM_H_ */

