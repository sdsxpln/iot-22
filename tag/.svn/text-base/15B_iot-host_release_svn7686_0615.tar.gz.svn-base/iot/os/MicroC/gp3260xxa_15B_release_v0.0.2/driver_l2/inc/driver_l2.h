#ifndef DRIVER_L2_H
#define DRIVER_L2_H

#include "driver_l1.h"
#include "driver_l2_cfg.h"

extern void drv_l2_init(void);

#endif		// __DRIVER_L2_H__
