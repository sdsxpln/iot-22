#ifndef __VIDENC_CFG_H__
#define __VIDENC_CFG_H__

#define VID_ENC_SYMC_TIMER		TIMER_C 		// timer, A,B,C
#define VID_ENC_TIME_BASE		50				// timer frequency must >= frame rate

#define DISP_BUF_NUM			3				// display buffer number
#define VIDEO_BUF_NUM			3				// video buffer number
#define JPEG_FIFO_LINE			32				// fifo line size
#define FIFO_BUF_NUM			6				// fifo buffer number
#endif //__VIDENC_CFG_H__