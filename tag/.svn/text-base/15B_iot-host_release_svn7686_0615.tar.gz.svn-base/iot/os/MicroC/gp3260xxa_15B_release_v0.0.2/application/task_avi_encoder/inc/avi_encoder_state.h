#ifndef __AVI_ENCODE_STATE_H__
#define __AVI_ENCODE_STATE_H__

#include "avi_encoder_app.h"

#endif //__AVI_ENCODE_STATE_H__