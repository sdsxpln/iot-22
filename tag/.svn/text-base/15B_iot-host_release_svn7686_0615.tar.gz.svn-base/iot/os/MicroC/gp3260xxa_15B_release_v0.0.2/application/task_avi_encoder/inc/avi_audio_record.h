#ifndef __AVI_AUDIO_RECORD_H__
#define __AVI_AUDIO_RECORD_H__

#include "avi_encoder_app.h"

#endif //__AVI_AUDIO_RECORD_H__
