#ifndef __GPLIB_BMP_H__
#define __GPLIB_BMP_H__


#include "gplib.h"



#endif 		// __GPLIB_BMP_H__