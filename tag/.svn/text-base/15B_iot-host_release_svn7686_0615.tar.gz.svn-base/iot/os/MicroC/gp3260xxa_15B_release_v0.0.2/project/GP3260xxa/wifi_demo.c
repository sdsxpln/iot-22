extern int ssv6xxx_dev_init(int argc, char *argv[]);

int wifi_demo(int argc, char *argv[])
{
    ssv6xxx_dev_init(argc, argv);
}

